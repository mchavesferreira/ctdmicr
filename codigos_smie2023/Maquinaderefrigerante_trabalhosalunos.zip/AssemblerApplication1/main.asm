; c�digo inicial maquina refri_ Adapta��o grupo ROM
; 

;  registradores e espa�os de mem�ria

 .def reg_temporario = r20


; espa�o de mem�ria 
;.equ inseriu_cartao = 0x10A
;.equ  quantidade_bicos = 0x101   // 0-255
.equ  quantidaliquidoPMG = 0x102  // 1 2 3=  m
.equ  tempo_quantidaliquidoPMG = 0x10F  // 3seg
.equ  deseja_gelo = 0x103  // 0 1 falso verdadeiro
.equ  quantidade_gelo = 0x106
.equ  tempo_gelo = 0x104   // 6 seg 
.equ  escolha_agua_refri = 0x100   // 0 1   falso verdadeiro
.equ  escolha_refri = 0x105
.equ  com_sem_gas = 0x107
.equ  coca_zero_normal = 0x108
.equ  guarana_zero_normal = 0x109

; pinos entrada
 .equ altera = PC0  ; entrada
 .equ enter = PC1
 .equ sensor_presenca = PC2  ///////
 .equ sensor_cartao = PC3
 .equ sensor_minimo_gelo = PC4
 ; pinos sa�da
 .equ valv_gelo = PB0  ; saida
 .equ valv_agua_sem_gas = PB1  ; saida
 .equ valv_agua_com_gas = PB2
 .equ valv_coca = PB3
 .equ valv_coca_zero = PB4
 .equ valv_guarana = PB5
 .equ valv_guarana_zero = PD0
 .equ valv_sprite = PD1

 .org 0x00
    rjmp  Inicio
    .include "biblioteca.inc"
	.include "mensagens_LCD.inc"

Inicio:
	ldi aux, 0b00000000  ; 
	out DDRC, aux ; definiu PORTC ENTRADA
	ldi aux, 0b11111111
	out PORTC, aux  ; ativou pull up em PORTC
	ldi aux, 0b11111111
	out DDRB, aux  ;;  definiu PORTB SAIDA
	out DDRD, aux  ;   definiu PORTD SAIDA

; valores iniciais para os registradores
    ldi reg_temporario, 1
	;sts  quantidade_bicos, reg_temporario
	sts  quantidaliquidoPMG, reg_temporario
	sts  escolha_agua_refri, reg_temporario
	sts  escolha_refri, reg_temporario
    ldi reg_temporario, 0
	sts  deseja_gelo, reg_temporario
	sts  quantidade_gelo, reg_temporario
	sts  com_sem_gas, reg_temporario
	sts  coca_zero_normal, reg_temporario
	sts  guarana_zero_normal, reg_temporario


 	rcall lcd_init ; inicializa LCD	
	rcall lcd_clear ; limpa LCD


; imprime mensagem de bem vindo por 2 segundos
    rcall msg_ola
	ldi delay_time, 2  ; define tempo 
	rcall delay_seconds ; chama rotina de tempo
;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;;  ;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;;   
;;  MENU DE escolha - repita para cada escolha : quantidade_bicos
; INICIO  - -  - - - - - - - -  - -    -   -    -   -    -   -   -   -  - - -  - - - - - - - -  - -    -   -    -   -    -   -   -   -  -
;Menu_quantidadebicos:
;    rcall lcd_clear ; limpa LCD
;   rcall msg_quantasxicaras
;Escolha_quantidadebicos:
;	ldi lcd_col,8  
;	rcall lcd_lin1_col  ; chama rotina posicionando na segunda linha 
;	lds reg_temporario, quantidade_bicos ; recupera valor da SRAM 
;	mov lcd_number, reg_temporario ; move valor para imprimir TL1
;	rcall lcd_write_number
; BOTAO ALTERAR
;	sbis PINC, 0 ; testa pino C0 sem pressionar =1 pula linha <Altera>
;	rjmp Aum_bicos ; botao pressionado
; BOTAO ENTER
;	sbis PINC, 1 ; testa pino C1 sem pressionar =1 pula linha  <Enter>
;	rjmp Menu_quantidadeaguaPMG ; botao pressionado pula para proxima etapa
;	rjmp Escolha_quantidadebicos ; retorna

;Aum_bicos:
;    inc reg_temporario   ; incrementa registrador
 ; teste maximo 
;    cpi reg_temporario, 3  ;compara o registrador ultrapassou o valor imediato ap�s ,
;	brne Aum_bicos_continua  ; pula se nao forem iguais
;	ldi reg_temporario, 1  ; reinicia registrador em 1

;Aum_bicos_continua:
;	sts  quantidade_bicos, reg_temporario  ; armazena reg temporario em sram
;	ldi delay_time,255  
;	rcall delay_miliseconds  ; atraso para o botao pressionado
;	ldi delay_time,255  
;	rcall delay_miliseconds  ; atraso para o botao pressionado
;	rjmp Escolha_quantidadebicos

; FIM DO MENU - -  - - - - - - - -  - -    -   -    -   -    -   -   -   -  - - -  - - - - - - - -  - -    -   -    -   -    -   -   -   -  -

;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;;  ;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;;   
;;  MENU DE escolha - repita para cada variavel : quantidadeliquidoPMG
; INICIO  - -  - - - - - - - -  - -    -   -    -   -    -   -   -   -  - - -  - - - - - - - -  - -    -   -    -   -    -   -   -   -  -

Menu_quantidadeliquidoPMG:
    rcall lcd_clear ; limpa LCD
    rcall msg_quantidadeliquidoPMG
Escolha_quantidadeliquidoPMG:
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado 
	lds reg_temporario, quantidaliquidoPMG ; recupera valor da SRAM 
	ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp Nao_pequeno ; nao igual 
      rjmp Pequeno ;
Pequeno:
    rcall msg_pequeno
	rjmp BOTAO_ALTERAR
Nao_pequeno:
    lds reg_temporario, quantidaliquidoPMG ; recupera valor da SRAM 
	ldi aux,2
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp grande ; nao igual 
      rjmp medio ;
medio:
    rcall msg_medio
	rjmp BOTAO_ALTERAR
grande:
    rcall msg_grande
	rjmp BOTAO_ALTERAR
BOTAO_ALTERAR:
	sbis PINC, 0 ; testa pino C0 sem pressionar =1 pula linha <Altera>
	rjmp Aum_quantidadeliquidoPMG ; botao pressionado
; BOTAO ENTER
	sbis PINC, 1 ; testa pino C1 sem pressionar =1 pula linha  <Enter>
	rjmp Menu_deseja_gelo ; botao pressionado pula para proxima etapa
	rjmp Escolha_quantidadeliquidoPMG  ; retorna

Aum_quantidadeliquidoPMG:
    inc reg_temporario   ; incrementa registrador
 ; teste maximo 
    cpi reg_temporario, 4 ;compara o registrador ultrapassou  o valor imediato ap�s ,
	brne quantidadeliquidoPMG_continua  ; pula se nao forem iguais
	ldi reg_temporario, 1  ; reinicia registrador em 1

quantidadeliquidoPMG_continua:
	sts  quantidaliquidoPMG, reg_temporario  ; armazena reg temporario em sram
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	rjmp Escolha_quantidadeliquidoPMG	

; FIM DO MENU - -  - - - - - - - -  - -    -   -    -   -    -   -   -   -  - - -  - - - - - - - -  - -    -   -    -   -    -   -   -   -  -


;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;;  ;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;;   
;;  MENU DE escolha - repita para cada variavel : deseja_gelo
; INICIO  - -  - - - - - - - -  - -    -   -    -   -    -   -   -   -  - - -  - - - - - - - -  - -    -   -    -   -    -   -   -   -  -
Menu_deseja_gelo:
    rcall lcd_clear ; limpa LCD
    rcall msg_deseja_gelo
Escolha_deseja_gelo:
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	lds reg_temporario, deseja_gelo ; recupera valor da SRAM
	 ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp nao ; nao igual 
      rjmp sim
nao:
    rcall msg_nao
	rjmp BOTAO_ALTERAR1
sim:
    rcall msg_sim
	rjmp BOTAO_ALTERAR1
BOTAO_ALTERAR1:
	sbis PINC, 0 ; testa pino C0 sem pressionar =1 pula linha <Altera>
	rjmp Aum_deseja_gelo ; botao pressionado
; BOTAO ENTER
	sbis PINC, 1 ; testa pino C1 sem pressionar =1 pula linha  <Enter>
	rjmp Sim_nao_gelo ; botao pressionado pula para proxima etapa
	rjmp Escolha_deseja_gelo  ; retorna

Aum_deseja_gelo:
    inc reg_temporario   ; incrementa registrador
 ; teste maximo 
    cpi reg_temporario, 2 ;compara o registrador ultrapassou  o valor imediato ap�s ,
	brne deseja_gelo_continua  ; pula se nao forem iguais
	ldi reg_temporario, 0  ; reinicia registrador em 0

deseja_gelo_continua:
	sts  deseja_gelo, reg_temporario  ; armazena reg temporario em sram
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	rjmp Escolha_deseja_gelo	

	;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;;  ;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;; 
	
Sim_nao_gelo:
   lds reg_temporario, deseja_gelo
   ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp Menu_escolha_agua_refri ; nao igual 
      rjmp Menu_quantidade_gelo ;

;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;;  ;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;; 
;;  MENU DE escolha - repita para cada variavel : quantidade_gelo
Menu_quantidade_gelo:
    rcall lcd_clear ; limpa LCD
    rcall msg_quantidade_gelo
Escolha_quantidade_gelo:
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	lds reg_temporario, quantidade_gelo ; recupera valor da SRAM 
	ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp pouco ; nao igual 
      rjmp muito
pouco:
    rcall msg_pouco
	rjmp BOTAO_ALTERAR2
muito:
    rcall msg_muito
	rjmp BOTAO_ALTERAR2
BOTAO_ALTERAR2:
	sbis PINC, 0 ; testa pino C0 sem pressionar =1 pula linha <Altera>
	rjmp Aum_quantidade_gelo ; botao pressionado
; BOTAO ENTER
	sbis PINC, 1 ; testa pino C1 sem pressionar =1 pula linha  <Enter>
	rjmp Menu_escolha_agua_refri ; botao pressionado pula para proxima etapa
	rjmp Escolha_quantidade_gelo  ; retorna

Aum_quantidade_gelo:
    inc reg_temporario   ; incrementa registrador
 ; teste maximo 
    cpi reg_temporario, 2 ;compara o registrador ultrapassou  o valor imediato ap�s ,
	brne quantidade_gelo_continua  ; pula se nao forem iguais
	ldi reg_temporario, 0  ; reinicia registrador em 0

quantidade_gelo_continua:
	sts  quantidade_gelo, reg_temporario  ; armazena reg temporario em sram
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	rjmp Escolha_quantidade_gelo	

;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;;  ;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;; 
;;  MENU DE escolha - repita para cada variavel : escolha_agua_refri
Menu_escolha_agua_refri:
    rcall lcd_clear ; limpa LCD
    rcall msg_escolha_agua_refri
Escolha_escolha_agua_refri:
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	lds reg_temporario, escolha_agua_refri ; recupera valor da SRAM 
	ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp refri ; nao igual 
      rjmp agua
refri:
    rcall msg_refri
	rjmp BOTAO_ALTERAR3
agua:
    rcall msg_agua
	rjmp BOTAO_ALTERAR3
BOTAO_ALTERAR3:
	sbis PINC, 0 ; testa pino C0 sem pressionar =1 pula linha <Altera>
	rjmp Aum_escolha_agua_refri ; botao pressionado
; BOTAO ENTER
	sbis PINC, 1 ; testa pino C1 sem pressionar =1 pula linha  <Enter>
	rjmp Agua_escolhida ; botao pressionado pula para proxima etapa
	rjmp Escolha_escolha_agua_refri ; retorna

Aum_escolha_agua_refri:
    inc reg_temporario   ; incrementa registrador
 ; teste maximo 
    cpi reg_temporario, 3 ;compara o registrador ultrapassou  o valor imediato ap�s ,
	brne escolha_agua_refri_continua  ; pula se nao forem iguais
	ldi reg_temporario, 1  ; reinicia registrador em 0

escolha_agua_refri_continua:
	sts  escolha_agua_refri, reg_temporario  ; armazena reg temporario em sram
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	rjmp Escolha_escolha_agua_refri	

Agua_escolhida:
     lds reg_temporario, escolha_agua_refri
   ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp Menu_escolha_refri ; nao igual 
      rjmp Menu_com_sem_gas ;

;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;;  ;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;; 
;;  MENU DE escolha - repita para cada variavel : com_sem_gas
Menu_com_sem_gas:
    rcall lcd_clear ; limpa LCD
    rcall msg_com_sem_gas
Escolha_com_sem_gas:
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado 
	lds reg_temporario, com_sem_gas ; recupera valor da SRAM 
	ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp sem ; nao igual 
      rjmp com1
sem:
    rcall msg_sem
	rjmp BOTAO_ALTERAR4
com1:
    rcall msg_com
	rjmp BOTAO_ALTERAR4
BOTAO_ALTERAR4:
	sbis PINC, 0 ; testa pino C0 sem pressionar =1 pula linha <Altera>
	rjmp Aum_com_sem_gas ; botao pressionado
; BOTAO ENTER
	sbis PINC, 1 ; testa pino C1 sem pressionar =1 pula linha  <Enter>
	rjmp EM_OPERACAO ; botao pressionado pula para proxima etapa
	rjmp Escolha_com_sem_gas ; retorna

Aum_com_sem_gas:
    inc reg_temporario   ; incrementa registrador
 ; teste maximo 
    cpi reg_temporario, 2 ;compara o registrador ultrapassou  o valor imediato ap�s ,
	brne com_sem_gas_continua  ; pula se nao forem iguais
	ldi reg_temporario, 0  ; reinicia registrador em 0

com_sem_gas_continua:
	sts  com_sem_gas, reg_temporario  ; armazena reg temporario em sram
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	rjmp Escolha_com_sem_gas

;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;;  ;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;; 
;;  MENU DE escolha - repita para cada variavel : escolha_refri
Menu_escolha_refri:
    rcall lcd_clear ; limpa LCD
    rcall msg_escolha_refri
Escolha_escolha_refri:
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	lds reg_temporario, escolha_refri ; recupera valor da SRAM 
	ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp Nao_coc ; nao igual 
      rjmp Coc ;
Coc:
    rcall msg_coca
	rjmp BOTAO_ALTERAR5
Nao_coc:
    lds reg_temporario, escolha_refri ; recupera valor da SRAM 
	ldi aux,2
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp sprite ; nao igual 
      rjmp guarana ;
sprite:
    rcall msg_sprite
	rjmp BOTAO_ALTERAR5
guarana:
    rcall msg_guarana
	rjmp BOTAO_ALTERAR5
BOTAO_ALTERAR5:
	sbis PINC, 0 ; testa pino C0 sem pressionar =1 pula linha <Altera>
	rjmp Aum_escolha_refri ; botao pressionado
; BOTAO ENTER
	sbis PINC, 1 ; testa pino C1 sem pressionar =1 pula linha  <Enter>
	rjmp Refri_escolhido ; botao pressionado pula para proxima etapa
	rjmp Escolha_escolha_refri ; retorna

Aum_escolha_refri:
    inc reg_temporario   ; incrementa registrador
 ; teste maximo 
    cpi reg_temporario, 4 ;compara o registrador ultrapassou  o valor imediato ap�s ,
	brne escolha_refri_continua  ; pula se nao forem iguais
	ldi reg_temporario, 1  ; reinicia registrador em 0

escolha_refri_continua:
	sts  escolha_refri, reg_temporario  ; armazena reg temporario em sram
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	rjmp Escolha_escolha_refri

Refri_escolhido:
   lds reg_temporario, escolha_refri
   ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp Nao_coca ; nao igual 
      rjmp Menu_coca_zero_normal ;

Nao_coca:
   lds reg_temporario, escolha_refri
   ldi aux,2
   CPSE reg_temporario, aux   ;  testa se =2  pula pr�xima linha
      rjmp EM_OPERACAO ; nao igual 
      rjmp Menu_guarana_zero_normal ;

;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;;  ;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;; 
;;  MENU DE escolha - repita para cada variavel : coca_zero_normal
Menu_coca_zero_normal:
    rcall lcd_clear ; limpa LCD
    rcall msg_zero_normal
Escolha_coca_zero_normal:
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	lds reg_temporario, coca_zero_normal ; recupera valor da SRAM 
	ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp zero ; nao igual 
      rjmp normal
zero:
    rcall msg_zero
	rjmp BOTAO_ALTERAR6
normal:
    rcall msg_normal
	rjmp BOTAO_ALTERAR6
BOTAO_ALTERAR6:
	sbis PINC, 0 ; testa pino C0 sem pressionar =1 pula linha <Altera>
	rjmp Aum_coca_zero_normal ; botao pressionado
; BOTAO ENTER
	sbis PINC, 1 ; testa pino C1 sem pressionar =1 pula linha  <Enter>
	rjmp EM_OPERACAO ; botao pressionado pula para proxima etapa
	rjmp Escolha_coca_zero_normal ; retorna

Aum_coca_zero_normal:
    inc reg_temporario   ; incrementa registrador
 ; teste maximo 
    cpi reg_temporario, 2 ;compara o registrador ultrapassou  o valor imediato ap�s ,
	brne coca_zero_normal_continua  ; pula se nao forem iguais
	ldi reg_temporario, 0  ; reinicia registrador em 0

coca_zero_normal_continua:
	sts  coca_zero_normal, reg_temporario  ; armazena reg temporario em sram
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	rjmp Escolha_coca_zero_normal

;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;;  ;;;;;;;;;;;;;;;;;;;;;; ;;;;;;;;;;;;;;;;;;;;;;   ;;;;;;;;;;;;;;;;;;;;;; 
;;  MENU DE escolha - repita para cada variavel : guarana_zero_normal
Menu_guarana_zero_normal:
    rcall lcd_clear ; limpa LCD
    rcall msg_zero_normal
Escolha_guarana_zero_normal:
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	lds reg_temporario, guarana_zero_normal ; recupera valor da SRAM 
	ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
       rjmp zero1 ; nao igual 
       rjmp normal1
zero1:
    rcall msg_zero
	rjmp BOTAO_ALTERAR7
normal1:
    rcall msg_normal
	rjmp BOTAO_ALTERAR7
BOTAO_ALTERAR7:
	sbis PINC, 0 ; testa pino C0 sem pressionar =1 pula linha <Altera>
	rjmp Aum_guarana_zero_normal ; botao pressionado
; BOTAO ENTER
	sbis PINC, 1 ; testa pino C1 sem pressionar =1 pula linha  <Enter>
	rjmp EM_OPERACAO ; botao pressionado pula para proxima etapa
	rjmp Escolha_guarana_zero_normal ; retorna

Aum_guarana_zero_normal:
    inc reg_temporario   ; incrementa registrador
 ; teste maximo 
    cpi reg_temporario, 2 ;compara o registrador ultrapassou  o valor imediato ap�s ,
	brne guarana_zero_normal_continua  ; pula se nao forem iguais
	ldi reg_temporario, 0  ; reinicia registrador em 0

guarana_zero_normal_continua:
	sts  guarana_zero_normal, reg_temporario  ; armazena reg temporario em sram
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	ldi delay_time,255  
	rcall delay_miliseconds  ; atraso para o botao pressionado
	rjmp Escolha_guarana_zero_normal

; FIM DO MENU - -  - - - - - - - -  - -    -   -    -   -    -   -   -   -  - - -  - - - - - - - -  - -    -   -    -   -    -   -   -   -  -
;;;;  outras configura��es MENU



	;;;;;;;;;;================================================================================
	;;;;;;;;;;;;;  inicializando  maquina de lavar imprime EM OPERACAO

EM_OPERACAO:
    rcall msg_EMOPERACAO
    ldi delay_time, 2
	rcall delay_seconds

;;;;  verifica quantidade presenca de copo
testa_copo:    
	rcall msg_colocar_copo
	sbic pinc,2
	rjmp testa_copo  ;; retorna at� que copo seja colocado
	rcall msg_copo_inserido

	ldi delay_time, 2
	rcall delay_seconds

;;;;  verifica presenca de cartao
testa_cartao:    
	rcall msg_colocar_cartao
	sbic pinc,3
	rjmp testa_cartao  ;; retorna at� que copo seja colocado
	rcall msg_cartao_inserido

	ldi delay_time, 2
	rcall delay_seconds

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
	;;;;TestE: ativa segundo bico para 2 xicaras
;Em_operacao_bicos:
;	lds  reg_temporario, quantidade_bicos  ; recupera valor da sram
;	ldi aux,2   ; carrega aux=r16 com valor 2
;	CPSE reg_temporario, aux   ;  testa se =2  pula pr�xima linha
;     rjmp Nao_ativar_segundo_bico ; nao igual 
;     rjmp Ativar_segundo_bico ; =

;Ativar_segundo_bico:
;      sbi portb,valv_segundo_bico
;Nao_ativar_segundo_bico:
      ;;;;;

;;;   nao ativa segundo bico para xicara

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;Testa se quantidade de agua PMG
Em_operacao_quantidade_liquido:
;    rcall msg_preparo_liquido
	;; se 1=3 segundos ativo , se 2=6 segundos e 3=9 segundos
	;; tempos fixos para agua com e sem gas, coca normal e zero, guarana normal e zero, sprite
	;; gelo em pouca quantidade se 1=2 segundos, se 2=4 segundos e se 3=6 segundos
	;; gelo em muita quantidade se 1=4 segundos, se 2=8 segundos e se 3=12 segundos
;; se a xicara tem tamanho 1:
	lds  reg_temporario, quantidaliquidoPMG  ; recupera valor da sram
	ldi aux,1   ; carrega aux=r16 com valor 2
	CP reg_temporario, aux   ;  testa se =1  pula pr�xima linha
	breq Seta_tempos_tamanhoP

	ldi aux,2   ; carrega aux=r16 com valor 2
	CP reg_temporario, aux   ;  testa se =2  pula pr�xima linha
	breq Seta_tempos_tamanhoM

	ldi aux,3   ; carrega aux=r16 com valor 2
	CP reg_temporario, aux   ;  testa se =3  pula pr�xima linha
	breq Seta_tempos_tamanhoG
    
Seta_tempos_tamanhoP:
  ldi aux,3
  sts tempo_quantidaliquidoPMG, aux
  lds  reg_temporario, quantidade_gelo
  ldi aux,1
  CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp Pouco_geloP ; nao igual 
      rjmp Muito_geloP

Pouco_geloP:
  ldi aux,2
  sts tempo_gelo, aux
;;;;
  rjmp testa_gelo

Muito_geloP:
  ldi aux,4
  sts tempo_gelo, aux
;;;;
  rjmp testa_gelo

Seta_tempos_tamanhoM:
  ldi aux,6
  sts tempo_quantidaliquidoPMG, aux
   lds  reg_temporario, quantidade_gelo
  ldi aux,1
  CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp Pouco_geloM ; nao igual 
      rjmp Muito_geloM

Pouco_geloM:
  ldi aux,4
  sts tempo_gelo, aux
;;;;
  rjmp testa_gelo

Muito_geloM:
  ldi aux,8
  sts tempo_gelo, aux
;;;;
  rjmp testa_gelo

Seta_tempos_tamanhoG:
  ldi aux,9
  sts tempo_quantidaliquidoPMG, aux
  lds  reg_temporario, quantidade_gelo
  ldi aux,1
  CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp Pouco_geloG ; nao igual 
      rjmp Muito_geloG

Pouco_geloG:
  ldi aux,6
  sts tempo_gelo, aux
;;;;
  rjmp testa_gelo

Muito_geloG:
  ldi aux,12
  sts tempo_gelo, aux
;;;;
  rjmp testa_gelo

testa_gelo:    
	sbic pinc,4
	rjmp com_gelo  
	rjmp sem_gelo

com_gelo:
    rcall msg_com_gelo
	ldi delay_time, 2
	rcall delay_seconds
	rjmp Em_operacao_gelo


sem_gelo:
    rcall msg_sem_gelo
	ldi delay_time, 2
	rcall delay_seconds
	rjmp Nao_ativar_gelo

	ldi delay_time, 2
	rcall delay_seconds

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
Em_operacao_gelo:
	lds  reg_temporario, deseja_gelo  ; recupera valor da sram Flag 
	ldi aux,1   ; carrega aux=r16 com valor 1
	CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp Nao_ativar_gelo 
      rjmp Ativar_gelo ; nao

Ativar_gelo: 
    rcall msg_preparo_gelo
	sbi portb, valv_gelo
	lds  reg_temporario, tempo_gelo ; recupera tempo de ativo cafe
	mov delay_time, reg_temporario
	rcall delay_seconds
	cbi portb, valv_gelo
Nao_ativar_gelo:
    lds reg_temporario, escolha_agua_refri
   ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp Escolhido_refri ; nao igual 
      rjmp Val_com_sem_gas ;

Val_com_sem_gas:   
   lds reg_temporario, com_sem_gas
   ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp Val_sem_gas ; nao igual 
      rjmp Val_com_gas ;

Escolhido_refri:
   lds reg_temporario, escolha_refri
   ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp Val_nao_coca ; nao igual 
      rjmp Val_coca_zero_normal

Val_nao_coca:
   lds reg_temporario, escolha_refri
   ldi aux,2
   CPSE reg_temporario, aux   ;  testa se =2  pula pr�xima linha
      rjmp Val_sprite ; nao igual 
      rjmp Val_guarana_zero_normal

Val_coca_zero_normal:
   lds reg_temporario, coca_zero_normal
   ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp Val_coca_zero ; nao igual 
      rjmp Val_coca_normal

Val_guarana_zero_normal:
   lds reg_temporario, guarana_zero_normal
   ldi aux,1
   CPSE reg_temporario, aux   ;  testa se =1  pula pr�xima linha
      rjmp Val_guarana_zero ; nao igual 
      rjmp Val_guarana_normal
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
Val_com_gas:
    rcall msg_preparo_com_gas
	sbi portb, valv_agua_com_gas
	lds  reg_temporario, tempo_quantidaliquidoPMG ; recupera tempo de ativo cafe
	mov delay_time, reg_temporario
	rcall delay_seconds
	cbi portb, valv_agua_com_gas
	rjmp fim_retira_copo

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
Val_sem_gas:
    rcall msg_preparo_sem_gas
	sbi portb, valv_agua_sem_gas
	lds  reg_temporario, tempo_quantidaliquidoPMG ; recupera tempo de ativo cafe
	mov delay_time, reg_temporario
	rcall delay_seconds
	cbi portb, valv_agua_sem_gas
	rjmp fim_retira_copo

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
Val_sprite:
    rcall msg_preparo_sprite
	sbi portd, valv_sprite
	lds  reg_temporario, tempo_quantidaliquidoPMG ; recupera tempo de ativo cafe
	mov delay_time, reg_temporario
	rcall delay_seconds
	cbi portd, valv_sprite
	rjmp fim_retira_copo

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
Val_coca_zero:
    rcall msg_preparo_coca_zero
	sbi portb, valv_coca_zero
	lds  reg_temporario, tempo_quantidaliquidoPMG ; recupera tempo de ativo cafe
	mov delay_time, reg_temporario
	rcall delay_seconds
	cbi portb, valv_coca_zero
	rjmp fim_retira_copo

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
Val_coca_normal:
    rcall msg_preparo_coca
	sbi portb, valv_coca
	lds  reg_temporario, tempo_quantidaliquidoPMG ; recupera tempo de ativo cafe
	mov delay_time, reg_temporario
	rcall delay_seconds
	cbi portb, valv_coca
	rjmp fim_retira_copo

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
Val_guarana_zero:
    rcall msg_preparo_guarana_zero
	sbi portd, valv_guarana_zero
	lds  reg_temporario, tempo_quantidaliquidoPMG ; recupera tempo de ativo cafe
	mov delay_time, reg_temporario
	rcall delay_seconds
	cbi portd, valv_guarana_zero
	rjmp fim_retira_copo

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
Val_guarana_normal:
    rcall msg_preparo_guarana
	sbi portb, valv_guarana
	lds  reg_temporario, tempo_quantidaliquidoPMG ; recupera tempo de ativo cafe
	mov delay_time, reg_temporario
	rcall delay_seconds
	cbi portb, valv_guarana
	rjmp fim_retira_copo

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;  desliga segundo bico
;    cbi portb,0

;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

fim_retira_copo:    
	rcall msg_retirar_copo
testa_retira_copo:
	sbic pinc,2
	rjmp testa_retira_copo  ;; retorna at� que copo seja colocado
	rjmp Inicio

	;;;;;;;; 


