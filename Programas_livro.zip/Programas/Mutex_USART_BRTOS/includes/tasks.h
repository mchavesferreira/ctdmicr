
/***************************************************************************************************
*                                              OS Tasks
***************************************************************************************************/

#include "hardware.h"

void Usa_serial_1(void);
void Usa_serial_2(void);

void Transmite_Uptime(void);
void Transmite_Duty_Cycle(void);
void Transmite_RAM_Ocupada(void);
void Transmite_Task_Stacks(void);
void Transmite_CPU_Load(void);
void Reason_of_Reset(void);
