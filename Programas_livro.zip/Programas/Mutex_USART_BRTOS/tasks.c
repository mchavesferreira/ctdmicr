#include "BRTOS.h"
#include "drivers.h"
#include "tasks.h"

extern BRTOS_Mutex *TestMutex;
extern BRTOS_Queue *Serial;

const CHAR8 SerialTeste1[] PROGMEM = "Esta eh a Tarefa 1";
const CHAR8 SerialTeste2[] PROGMEM = "Agora eh a Tarefa 2";

PGM_P TaskStringTable1[] PROGMEM = { SerialTeste1 };
PGM_P TaskStringTable2[] PROGMEM = { SerialTeste2 };
	
void Usa_serial_1(void)
{
	while(1)
	{
		strcpy_P(BufferText, (PGM_P)pgm_read_word(&(TaskStringTable1[0])));
		Serial_Envia_Frase((CHAR8*)BufferText);
		Serial_Envia_Caracter(LF);
		Serial_Envia_Caracter(CR);
		DelayTask(1);
	}
}	
//----------------------------------------------------------------------------	
void Usa_serial_2(void)
{
	while(1)
	{
		// Adquire Mutex
		OSMutexAcquire(TestMutex);
		strcpy_P(BufferText, (PGM_P)pgm_read_word(&(TaskStringTable2[0])));
		Serial_Envia_Frase((CHAR8*)BufferText);
		Serial_Envia_Caracter(LF);
		Serial_Envia_Caracter(CR);
		// Libera Mutex
		OSMutexRelease(TestMutex);
		DelayTask(1);
	}
}	
//----------------------------------------------------------------------------