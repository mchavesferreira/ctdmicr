//------------------------------------------------------------------------- //
//		AVR e Arduino: T�cnicas de Projeto, 2a ed. - 2012.					//	
//-------------------------------------------------------------------------	//

#include "BRTOS.h"
#include "tasks.h"
#include "serial.h"

#define FOSC 16000000 // Clock Speed
#define BAUD 1200
#define MYBAUD (FOSC/16/BAUD)-1

const CHAR8 Task1Name[] PROGMEM = "Usa_serial_1";
const CHAR8 Task2Name[] PROGMEM = "Usa_serial_2";

PGM_P MainStringTable[] PROGMEM =
{
    Task1Name,
	Task2Name
};

BRTOS_Mutex *TestMutex;
BRTOS_Queue  *Serial;

int main(void)
{
  	BRTOS_Init();    
	Serial_Init(MYBAUD);

	/* Argumentos da fun��o que cria um Mutex: 1 - O endere�o de um ponteiro do tipo �bloco de controle de mutex� 
	(BRTOS_Mutex) que receber� o endere�o do bloco de controle alocado para o mutex criado.
	2 - A prioridade que ser� associada ao mutex e que deve ser sempre um n�vel maior
	do que a maior prioridade das tarefas que ir�o competir por um determinado recurso.
	3 - A tarefa 	que recebe o recurso passa a prioridade do mutex , n�o sendo interrompida pelas tarefas que
	competem pelo mesmo recurso. A tarefa volta a sua prioridade original quando liberar este recurso */
	
	if (OSMutexCreate(&TestMutex,7) != ALLOC_EVENT_OK)
		while(1){};// Oh Oh - N�o deveria entrar aqui !!!
	
	if(InstallTask(&Usa_serial_1,Task1Name,100,6) != OK)
		while(1){};// Oh Oh - N�o deveria entrar aqui !!!
		
	if(InstallTask(&Usa_serial_2,Task2Name,100,5) != OK)
		while(1){};// Oh Oh - N�o deveria entrar aqui !!!
		
	// Start Task Scheduler
	if(BRTOSStart() != OK)
		while(1){};// Oh Oh - N�o deveria entrar aqui !!!
	
	while(1);
}
