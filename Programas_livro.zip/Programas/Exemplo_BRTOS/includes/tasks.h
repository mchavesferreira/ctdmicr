/***************************************************************************************************
*                                               BRTOS
*                                Brazilian Real-Time Operating System
*                            Acronymous of Basic Real-Time Operating System
*                                  Open Source RTOS under MIT License
*  OS Tasks
***************************************************************************************************/

#include "hardware.h"

void Multiplexa_Display(void);
void Incrementa_Contagem(void);
void Decrementa_Contagem(void);
void Inicializa_Contagem(void);

void Transmite_Uptime(void);
void Transmite_Duty_Cycle(void);
void Transmite_RAM_Ocupada(void);
void Transmite_Task_Stacks(void);
void Transmite_CPU_Load(void);
void Reason_of_Reset(void);
