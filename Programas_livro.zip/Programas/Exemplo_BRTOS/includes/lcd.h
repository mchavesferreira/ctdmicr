void write_lcd(char *string);
void instr(char comando);
void caractere(char dado);
void write_numero(unsigned char numero);
void init_lcd(void);
void init_lcd_resource(void);
void posiciona(byte linha, byte coluna);
void limpa_lcd(void);