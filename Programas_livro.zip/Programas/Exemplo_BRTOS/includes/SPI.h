void init_SPI1(void);
void SPISendChar (INT8U data);
INT8U SPIGet(void);