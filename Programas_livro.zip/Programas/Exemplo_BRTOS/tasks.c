#include "BRTOS.h"
#include "drivers.h"
#include "tasks.h"

#define DEBOUNCE 10
#define MUX 2

#define botao_INCREMENTO  !(PINB&(1<<PINB2))	//leitura do botao de incremento
#define botao_DECREMENTO  !(PINB&(1<<PINB3))	//leitura do botao de decremento
#define botao_RESET		  !(PINB&(1<<PINB4))	//leitura do botao de reset

const char tabela[16] PROGMEM = {0x40, 0x79, 0x24, 0x30, 0x19, 0x12,0x02, 0x78,  0x00, 0x18, 0x08, 0x03, 0x46, 0x21, 0x06, 0x0E};
volatile unsigned char cont;

//-------------------------------------------------------------------------				
void Multiplexa_Display()
{
	while(1)
	{
		 PORTB &=  0xFD;				//desliga display 2
		 PORTD = pgm_read_byte(&tabela[cont/16]);//valor no display 1
		 PORTB |=  0x01;				//liga display 1
		 DelayTask(MUX);				//espera por intervalo: MUX ticks
		 PORTB &=  0xFE;				//desliga display 1
		 PORTD = pgm_read_byte(&tabela[cont%16]);//valor no display 2
		 PORTB |=  0x02;				//liga display 2
		 DelayTask(MUX);				//espera por intervalo: MUX ticks                       
	}		
}			
//-------------------------------------------------------------------------	
void Incrementa_Contagem()
{	
	while(1)
	{
		if(botao_INCREMENTO)
		{ 
			cont++;
			DelayTask(200);
		}	
		else 	
			DelayTask(1);
	}
}
//-------------------------------------------------------------------------	
void Decrementa_Contagem()
{
	while(1)
	{
		 if(botao_DECREMENTO)
		 { 
			cont--;
			DelayTask(200);	  /* aguarda expirar o tempo: DEBOUNCE ticks   */
		}		
		else 	
			DelayTask(1);
	}
}
//-------------------------------------------------------------------------	
void Inicializa_Contagem(void)
{
	while(1)
	{                        
 		if(botao_RESET)
			cont=0;
		else 	
			DelayTask(1);	
	}
}
//-------------------------------------------------------------------------	
