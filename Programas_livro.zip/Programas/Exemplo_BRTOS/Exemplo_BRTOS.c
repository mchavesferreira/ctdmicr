//------------------------------------------------------------------------- //
//		AVR e Arduino: T�cnicas de Projeto, 2a ed. - 2012.					//	
//-------------------------------------------------------------------------	//

#include "BRTOS.h"
#include "tasks.h"
#define FOSC 16000000		//frequ�ncia da CPU

// Associa nomes as tarefas
const CHAR8 Task1Name[] PROGMEM = "Multiplexa_Display";
const CHAR8 Task2Name[] PROGMEM = "Incrementa_Contagem";
const CHAR8 Task3Name[] PROGMEM = "Decrementa_Contagem";
const CHAR8 Task4Name[] PROGMEM = "Inicializa_Contagem";

PGM_P MainStringTable[] PROGMEM =
{
    Task1Name,
	Task2Name,
	Task3Name,
	Task4Name
};
//--------------------------------------------------------------------------
void avr_Init()		//inicializa��o dos registradores do microcontrolador utilizado
{
	DDRD  = 0xFF;
	PORTD =	0xFF;
	DDRB  = 0b00000011;
	PORTB = 0b11111100;
}
//--------------------------------------------------------------------------
int main(void)
{
	avr_Init();		//inicializa��o dos registradores do microcontrolador utilizado
	BRTOS_Init();	//inicializa��o do BRTOS
   
	/* Instala todas as tafefas no seguinte formato:
	(Endere�o da tarefa, Nome da tarefa, N�mero de Bytes do Stack Virtual, Prioridade da Tarefa)    
	Cada tarefa deve possuir uma prioridade   
	A instala��o de uma tarefa em um prioridade ocupada gerar� um c�digo de exce��o*/

	if(InstallTask(&Multiplexa_Display,Task1Name,40,4) != OK)
		while(1){};	// Oh Oh - N�o deveria entrar aqui !!!
  
	if(InstallTask(&Incrementa_Contagem,Task2Name,40,2) != OK)
		while(1){};	// Oh Oh - N�o deveria entrar aqui !!!
 
	if(InstallTask(&Decrementa_Contagem,Task3Name,40,1) != OK)
		while(1){};	// Oh Oh - N�o deveria entrar aqui !!!

	if(InstallTask(&Inicializa_Contagem,Task4Name,40,3) != OK)
		while(1){};	// Oh Oh - N�o deveria entrar aqui !!!
	
	// Inicializa��o do escalonador. A partir deste momento as tarefas instaladas come�am a ser executadas      
	if(BRTOSStart() != OK)
		while(1){};	// Oh Oh - N�o deveria entrar aqui !!!

	while(1){};		//la�o infinito
}
//--------------------------------------------------------------------------