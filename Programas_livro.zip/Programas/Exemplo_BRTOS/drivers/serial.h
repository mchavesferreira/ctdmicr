void Serial_Init(unsigned int baudrate);
void Serial_Envia_Caracter(unsigned char data);
void Serial_Envia_Frase(char *string);
