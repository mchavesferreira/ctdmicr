/*
 * Teste_Opt_Filtro_Med_Movel.c
 *
 * Created: 16-Aug-12 5:50:22 PM
 *  Author: borges
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>

unsigned int x[16], y; //filtro de 16 amostras

//--------------------------------------------------------------------------
ISR(ADC_vect)
{
	//---------------------------------------------------------------------
	unsigned char i=15;

	y=0;
	do
	{
		x[i] = x[i-1];	//anda um passo nas amostras anteriores
		y += x[i];
		i--;
	
	} while (i!=0);
		
	x[0]=ADC;			//nova amostra entra no filtro
	y = (y + x[0])/16;	//sinal filtrado
	//---------------------------------------------------------------------

/*
	static unsigned char i=0;
	unsigned char j=16;
	
	
	x[i]=ADC;		//sobre escreve o valor mais antigo
	i++;
	if(i>15)	i=0;
	
	y=0;
	do				//soma dos valores
	{
		j--;
		y+=x[j];
	} while (j!=0);
	
	y=y/16;			//media dos valores
	*/

}
//--------------------------------------------------------------------------

int main()
{	
	//configura ADC
	ADMUX  = 0b11000000;	//Tens�o interna de ref (1.1V), canal 0 
	ADCSRA = 0b11101111;	//habilita o AD, habilita interrup��o, modo de convers�o cont�nua, prescaler = 128 
	ADCSRB = 0x00;			//modo de convers�o cont�nua
	DIDR0 = 0xFE;			//desabilita pino PD0 como I/0, entrada do ADC0
		
	sei();
	
	while(1);
 
}
