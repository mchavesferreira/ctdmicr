//--------------------------------------------------------------------------------- //
//		AVR e Arduino: T�cnicas de Projeto, 2a ed. - 2012.							//	
//---------------------------------------------------------------------------------	//
//---------------------------------------------------------------------------------

#define F_CPU 16000000UL	
#include <avr/io.h> 	    	
#include <util/delay.h>			
#include <avr/pgmspace.h>

unsigned char msg=1;		//usado no assembly
const unsigned char msg1[] PROGMEM = "C COM ROTINA ASM\0";//mensagem 1 armazenada na mem�ria flash

extern void cmd_LCD(unsigned char, char);	//fun��o externa chamada pelo C
//---------------------------------------------------------------------------------
void atraso_ms(void)		//fun��o chamada pelo assembly
{
	_delay_ms(2);
}
//---------------------------------------------------------------------------------
void atraso_us(char tempo)	//fun��o chamada pelo assembly
{
	_delay_us(1);
	if(!tempo)_delay_us(39);
}
//---------------------------------------------------------------------------------
//Sub-rotina de inicializacao simplificada para 4 bits de dados do LCD
//---------------------------------------------------------------------------------
void inic_LCD(void)//envio de instrucoes para o LCD
{
	cmd_LCD(0x28,0);		//interface de 4 bits 
	cmd_LCD(0x28,0);		//interface de 4 bits 2 linhas (aqui se habilita as 2 linhas)
	cmd_LCD(0x0c,0);		//mensagem aparente cursor inativo n�o piscando
	cmd_LCD(0x01,0);		//limpa todo o display
	cmd_LCD(0x80,0);		//desloca o cursor para a posi��o 0x80
}
//---------------------------------------------------------------------------------
int main(void)
{
	unsigned char i;
	
	DDRD = 0xFF;			//porta D como sa�da
	inic_LCD( );			//inicializa o LCD
	
	for(i=0;(pgm_read_byte(&msg1[i]))!=0;i++)	//enviando caractere por caractere
		cmd_LCD(pgm_read_byte(&msg1[i]),1);		//l� na mem�ria flash e usa cmd_LCD
	
	while(1);				//la�o infinito
}
//---------------------------------------------------------------------------------