//----------------------------------------------------------------------------------- //
//		AVR e Arduino: T�cnicas de Projeto, 2a ed. - 2012.							  //	
//----------------------------------------------------------------------------------- //
//------------------------------------------------------------------------------------
#define F_CPU 16000000UL		
#include <avr/io.h> 	    	
#include <util/delay.h>			

#define	set_bit(adress,bit)	(adress|=(1<<bit))	
#define	clr_bit(adress,bit)	(adress&=~(1<<bit))	
#define tst_bit(adress,bit) (adress&(1<<bit))  	 
#define cpl_bit(adress,bit) (adress^=(1<<bit)) 	

#define DADOS_LCD    PORTD   
#define RS    PD2       	
#define E     PD3       	

//------------------------------------------------------------------------------------
//Sub-rotina para enviar comandos ao LCD com dados de 4 bits
//------------------------------------------------------------------------------------
void cmd_LCD(unsigned char c, char cd)
{
	static unsigned char i=1;
	
	DADOS_LCD = c;				//primeiro os 4 MSB. (PD4 - PD5 - PD6 - PD7) -> (D4 - D5 - D6 - D7 LCD)
						
	for(;i!=0;i--)
	{	
		if(cd==0)
			clr_bit(PORTD,RS);
		else
			set_bit(PORTD,RS);

		set_bit(PORTD,E);
		clr_bit(PORTD,E);
	    _delay_us(45);

		if((cd==0) && (c<4))	//se for instru��o espera tempo de resposta do display
		  _delay_ms(2);
	
		DADOS_LCD = c<<4;
	}
	i = 2;
}
//------------------------------------------------------------------------------------
//Sub-rotina de inicializacao simplificada para 4 bits de dados do LCD
//------------------------------------------------------------------------------------
void inic_LCD(void)		//envio de instrucoes para o LCD
{
	cmd_LCD(0x28,0);	//interface de 4 bits 
	cmd_LCD(0x28,0);	//interface de 4 bits 2 linhas (aqui se habilita as 2 linhas)
	cmd_LCD(0x0c,0);	//mensagem aparente cursor inativo nao piscando
	cmd_LCD(0x01,0);	//limpa todo o display
	cmd_LCD(0x80,0);	//desloca cursor para a posi��o 0x80
}
//------------------------------------------------------------------------------------
//Sub-rotina de escrita no LCD
//------------------------------------------------------------------------------------
void escreve_LCD(char *c)
{
   for (; *c!=0;c++) cmd_LCD(*c,1);
}
//------------------------------------------------------------------------------------