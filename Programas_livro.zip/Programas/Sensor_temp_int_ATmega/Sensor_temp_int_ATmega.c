//----------------------------------------------------------------------------------//
//		AVR e Arduino: T�cnicas de Projeto, 2a ed. - 2012.							//	
//----------------------------------------------------------------------------------//
//==================================================================================//
//	Lendo o sensor interno de temperatura do ATmega328								//
//==================================================================================//

#include "def_principais.h"
#include "USART.h"

#define Offset_temp 363				//valor do offset de temperatura

unsigned char digitos[tam_vetor];	//declara��o da vari�vel para armazenagem dos digitos (tam_vetor est� em USART.h)

const char msg[] PROGMEM = "Sensor Interno de Temperatura do ATmega328\n\0";

signed int le_temp();
//--------------------------------------------------------------------------------
int main(void)
{
    USART_Inic(MYUBRR);
	 
	ADMUX = (1<<REFS1) | (1<<REFS0) | (1<<MUX3);			//Tens�o interna de ref (1.1V), sensor de temp. do chip
	ADCSRA = (1<<ADEN) | (1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);	//habilita o AD e define um prescaler de 128 (clk_AD = F_CPU/128), 125 kHz
	 
	escreve_USART_Flash(msg);
	
	while(1)
	{
		ident_num((unsigned int)le_temp(),digitos);		//leitura de temperatura, sem sinal
		USART_Transmite(digitos[2]);
		USART_Transmite(digitos[1]);
		USART_Transmite(digitos[0]);
		USART_Transmite(176);							//simbolo 'o'
		USART_Transmite('C');
		USART_Transmite('\n');							//nova linha
		_delay_ms(1000);
	}
}			
//--------------------------------------------------------------------------------
signed int le_temp()
{
	set_bit(ADCSRA, ADSC);								//inicia a convers�o
	while(tst_bit(ADCSRA,ADSC));						//espera a convers�o ser finalizada
	
	return (ADC - Offset_temp);							//fator k de divis�o = 1
}
//--------------------------------------------------------------------------------

