//Exerc�cio 15.2

const char msg1 [] PROGMEM = " CONTROLANDO LEDs COM O COMPUTADOR\0";
const char msg2 [] PROGMEM = " LEDS ON -> 1, 2, 3, 4, LEDS OFF -> 5, 6, 7, 8\0";
const char msg3 [] PROGMEM = "             _         _ \0";
const char msg4 [] PROGMEM = "  ---\\/---  |_| \\  /  |_|  ---\\/---\0";
const char msg5 [] PROGMEM = "  ---/\\---  | |  \\/   | \\  ---/\\---\0";

	
